"""
Configuration — loaded from environment / .env file
"""
import os
from dataclasses import dataclass, field
from typing import List

from dotenv import load_dotenv

load_dotenv()


@dataclass
class Config:
    # ── Required ─────────────────────────────────────────────────────────────
    TELEGRAM_BOT_TOKEN: str = field(default_factory=lambda: os.getenv("TELEGRAM_BOT_TOKEN", ""))
    ANTHROPIC_API_KEY: str = field(default_factory=lambda: os.getenv("ANTHROPIC_API_KEY", ""))

    # ── Optional ─────────────────────────────────────────────────────────────
    OPENAI_API_KEY: str = field(default_factory=lambda: os.getenv("OPENAI_API_KEY", ""))
    DATABASE_PATH: str = field(default_factory=lambda: os.getenv("DATABASE_PATH", "expenses.db"))
    DEFAULT_CURRENCY: str = field(default_factory=lambda: os.getenv("DEFAULT_CURRENCY", "EUR"))

    # ── Security: whitelist of allowed Telegram user IDs (leave empty = allow all) ──
    ALLOWED_USER_IDS: List[int] = field(
        default_factory=lambda: [
            int(x.strip())
            for x in os.getenv("ALLOWED_USER_IDS", "").split(",")
            if x.strip().isdigit()
        ]
    )

    # ── AI Model settings ────────────────────────────────────────────────────
    PARSE_MODEL: str = field(
        default_factory=lambda: os.getenv("PARSE_MODEL", "claude-haiku-4-5-20251001")
    )
    VOICE_PROVIDER: str = field(
        default_factory=lambda: os.getenv("VOICE_PROVIDER", "openai")  # openai | whisper_local
    )

    def validate(self) -> None:
        errors = []
        if not self.TELEGRAM_BOT_TOKEN:
            errors.append("TELEGRAM_BOT_TOKEN is required")
        if not self.ANTHROPIC_API_KEY:
            errors.append("ANTHROPIC_API_KEY is required (used for expense parsing)")
        if self.VOICE_PROVIDER == "openai" and not self.OPENAI_API_KEY:
            errors.append(
                "OPENAI_API_KEY is required when VOICE_PROVIDER=openai. "
                "Set VOICE_PROVIDER=whisper_local to use local Whisper instead."
            )
        if errors:
            raise ValueError("Configuration errors:\n  • " + "\n  • ".join(errors))

    def is_user_allowed(self, user_id: int) -> bool:
        """Return True if no whitelist is configured, or if user_id is in the whitelist."""
        if not self.ALLOWED_USER_IDS:
            return True
        return user_id in self.ALLOWED_USER_IDS
