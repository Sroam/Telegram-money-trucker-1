"""
Message handlers — process text and voice input, parse, store expenses.
"""
from __future__ import annotations

import logging
from datetime import date

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from config import Config
from core.parser import ExpenseParser
from core.voice import VoiceTranscriber
from db.database import Database
from db.models import Expense
from utils.formatters import (
    fmt_expense_added_from_model,
    fmt_parse_failed,
    fmt_not_authorized,
)

logger = logging.getLogger(__name__)


class MessageHandlers:
    def __init__(self, db: Database, config: Config) -> None:
        self.db = db
        self.config = config
        self.parser = ExpenseParser(
            api_key=config.ANTHROPIC_API_KEY,
            model=config.PARSE_MODEL,
        )
        self.transcriber = VoiceTranscriber(
            provider=config.VOICE_PROVIDER,
            api_key=config.OPENAI_API_KEY,
        )

    # ── Auth guard ────────────────────────────────────────────────────────────

    def _check_auth(self, update: Update) -> bool:
        uid = update.effective_user.id  # type: ignore
        return self.config.is_user_allowed(uid)

    # ── Text messages ─────────────────────────────────────────────────────────

    async def handle_text(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            await update.message.reply_text(fmt_not_authorized())
            return

        user = update.effective_user
        text = update.message.text.strip()

        # Ensure user exists
        self.db.upsert_user(user.id, user.username or "", user.first_name or "")

        await self._process_text(update, user.id, text)

    # ── Voice messages ────────────────────────────────────────────────────────

    async def handle_voice(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            await update.message.reply_text(fmt_not_authorized())
            return

        user = update.effective_user
        self.db.upsert_user(user.id, user.username or "", user.first_name or "")

        # Download voice file
        processing_msg = await update.message.reply_text("🎤 Transcribing voice note…")

        try:
            voice = update.message.voice
            file = await ctx.bot.get_file(voice.file_id)
            audio_bytes = await file.download_as_bytearray()
        except Exception as e:
            logger.error(f"Voice download error: {e}")
            await processing_msg.edit_text("❌ Could not download voice note. Please try again.")
            return

        # Transcribe
        text = self.transcriber.transcribe(bytes(audio_bytes), filename="voice.ogg")

        if not text:
            await processing_msg.edit_text(
                "❌ Could not transcribe voice note.\n\n"
                "Make sure OPENAI\\_API\\_KEY is set, or try typing instead.",
                parse_mode=ParseMode.MARKDOWN,
            )
            return

        await processing_msg.edit_text(f"🎤 _Heard: {text}_", parse_mode=ParseMode.MARKDOWN)

        await self._process_text(update, user.id, text)

    # ── Core processing ───────────────────────────────────────────────────────

    async def _process_text(
        self, update: Update, user_id: int, text: str
    ) -> None:
        """Parse text and save expense, or return error feedback."""
        parsed = self.parser.parse(text, today=date.today())

        if parsed is None or parsed.amount is None:
            await update.message.reply_text(
                fmt_parse_failed(text), parse_mode=ParseMode.MARKDOWN
            )
            return

        # If confidence is very low, warn the user but still save
        if parsed.confidence < 0.4:
            await update.message.reply_text(
                f"🤔 *Low confidence parse* ({parsed.confidence:.0%}) — saving anyway.\n"
                f"Use /delete\\_last if this is wrong.",
                parse_mode=ParseMode.MARKDOWN,
            )

        expense = Expense(
            id=None,
            user_id=user_id,
            amount=parsed.amount,
            currency=parsed.currency,
            category=parsed.category,
            merchant=parsed.merchant,
            description=parsed.description,
            raw_input=parsed.raw_input,
            date=parsed.expense_date,
            created_at=__import__("datetime").datetime.now(),
        )

        expense_id = self.db.add_expense(expense)
        expense.id = expense_id

        logger.info(
            f"Expense saved: user={user_id} id={expense_id} "
            f"amount={expense.amount} category={expense.category} "
            f"confidence={parsed.confidence:.2f}"
        )

        await update.message.reply_text(
            fmt_expense_added_from_model(expense),
            parse_mode=ParseMode.MARKDOWN,
        )
