"""
Telegram command handlers — /today, /week, /month, /report, etc.
"""
from __future__ import annotations

import io
import logging
from datetime import date, timedelta

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from config import Config
from core.reports import ReportGenerator
from db.database import Database
from db.models import CATEGORY_EMOJI, CATEGORY_LABELS
from utils.export import expenses_to_csv, expenses_to_excel
from utils.formatters import (
    fmt_deleted,
    fmt_no_expenses,
    fmt_not_authorized,
    HELP_TEXT,
    START_TEXT,
)

logger = logging.getLogger(__name__)


class CommandHandlers:
    def __init__(self, db: Database, config: Config) -> None:
        self.db = db
        self.config = config
        self.reports = ReportGenerator(db)

    # ── Auth guard ────────────────────────────────────────────────────────────

    def _check_auth(self, update: Update) -> bool:
        uid = update.effective_user.id  # type: ignore
        return self.config.is_user_allowed(uid)

    # ── Info ──────────────────────────────────────────────────────────────────

    async def start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            await update.message.reply_text(fmt_not_authorized())
            return
        user = update.effective_user
        self.db.upsert_user(user.id, user.username or "", user.first_name or "")
        await update.message.reply_text(START_TEXT, parse_mode=ParseMode.MARKDOWN)

    async def help(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            return
        await update.message.reply_text(HELP_TEXT, parse_mode=ParseMode.MARKDOWN)

    # ── Views ─────────────────────────────────────────────────────────────────

    async def today(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            return
        uid = update.effective_user.id
        text = self.reports.daily_summary(uid, date.today())
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    async def week(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            return
        uid = update.effective_user.id
        text = self.reports.weekly_summary(uid)
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    async def month(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            return
        uid = update.effective_user.id
        text = self.reports.monthly_summary(uid)
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    async def expenses(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        """Show last 10 expenses."""
        if not self._check_auth(update):
            return
        uid = update.effective_user.id
        expenses = self.db.get_last_n(uid, 10)
        if not expenses:
            await update.message.reply_text(fmt_no_expenses(), parse_mode=ParseMode.MARKDOWN)
            return
        lines = ["*📋 Last 10 Expenses*\n"]
        for e in expenses:
            merchant_str = f" @ {e.merchant}" if e.merchant else ""
            lines.append(
                f"{e.category_emoji} *€{e.amount:.2f}* — {e.description}{merchant_str}  "
                f"_{e.date.strftime('%d %b')}_  _(#{e.id})_"
            )
        total = sum(e.amount for e in expenses)
        lines.append(f"\n💶 *Subtotal: €{total:.2f}*")
        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

    async def show_last(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        """Show last 5 expenses."""
        if not self._check_auth(update):
            return
        uid = update.effective_user.id
        expenses = self.db.get_last_n(uid, 5)
        if not expenses:
            await update.message.reply_text(fmt_no_expenses(), parse_mode=ParseMode.MARKDOWN)
            return
        lines = ["*🕐 Last 5 Expenses*\n"]
        for e in expenses:
            merchant_str = f" @ {e.merchant}" if e.merchant else ""
            lines.append(
                f"{e.category_emoji} *€{e.amount:.2f}* — {e.description}{merchant_str}  "
                f"_{e.date.strftime('%d %b')}_"
            )
        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

    # ── Reports ───────────────────────────────────────────────────────────────

    async def report(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            return
        uid = update.effective_user.id
        start, end = self.reports.month_range()
        text = self.reports.full_report(uid, start, end, f"Monthly Report — {start.strftime('%B %Y')}")
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    async def categories(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            return
        uid = update.effective_user.id
        start, end = self.reports.month_range()
        text = self.reports.category_report(uid, start, end, f"Categories — {start.strftime('%B %Y')}")
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    async def top_expenses(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            return
        uid = update.effective_user.id
        text = self.reports.top_expenses(uid, n=10)
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    # ── Edit / Undo ───────────────────────────────────────────────────────────

    async def delete_last(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            return
        uid = update.effective_user.id
        deleted = self.db.delete_last(uid)
        if deleted:
            await update.message.reply_text(
                fmt_deleted(deleted), parse_mode=ParseMode.MARKDOWN
            )
        else:
            await update.message.reply_text("Nothing to delete. No expenses found.")

    # ── Export ────────────────────────────────────────────────────────────────

    async def export_csv(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            return
        uid = update.effective_user.id
        expenses = self.db.get_all(uid)
        if not expenses:
            await update.message.reply_text("No expenses to export.")
            return
        csv_bytes = expenses_to_csv(expenses)
        filename = f"expenses_{date.today().isoformat()}.csv"
        await update.message.reply_document(
            document=io.BytesIO(csv_bytes),
            filename=filename,
            caption=f"📊 Your expenses ({len(expenses)} entries) — {date.today().strftime('%d %b %Y')}",
        )

    async def export_excel(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_auth(update):
            return
        uid = update.effective_user.id
        expenses = self.db.get_all(uid)
        if not expenses:
            await update.message.reply_text("No expenses to export.")
            return
        await update.message.reply_text("⏳ Generating Excel file…")
        xlsx_bytes = expenses_to_excel(expenses)
        if xlsx_bytes is None:
            await update.message.reply_text(
                "❌ Excel export requires openpyxl.\nRun: `pip install openpyxl`\n\n"
                "Use /export for CSV instead.",
                parse_mode=ParseMode.MARKDOWN,
            )
            return
        filename = f"expenses_{date.today().isoformat()}.xlsx"
        await update.message.reply_document(
            document=io.BytesIO(xlsx_bytes),
            filename=filename,
            caption=f"📊 Your expenses ({len(expenses)} entries) — {date.today().strftime('%d %b %Y')}",
        )
