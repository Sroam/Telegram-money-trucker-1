"""
Voice transcription — OpenAI Whisper API (primary) or local Whisper (fallback).

Whisper automatically detects language, handles Greek, German, English perfectly.
"""
from __future__ import annotations

import io
import logging
import os
import tempfile
from typing import Optional

logger = logging.getLogger(__name__)


class VoiceTranscriber:
    def __init__(self, provider: str = "openai", api_key: str = "") -> None:
        self.provider = provider
        self.api_key = api_key
        self._client = None

        if provider == "openai" and api_key:
            try:
                import openai
                self._client = openai.OpenAI(api_key=api_key)
                logger.info("VoiceTranscriber: OpenAI Whisper ready")
            except ImportError:
                logger.warning("openai package not installed — falling back to local Whisper")
                self.provider = "whisper_local"
        elif provider == "whisper_local":
            logger.info("VoiceTranscriber: local Whisper mode (lazy load)")

    def transcribe(self, audio_bytes: bytes, filename: str = "audio.ogg") -> Optional[str]:
        """
        Transcribe audio bytes to text.
        Returns None if transcription fails.
        """
        if self.provider == "openai" and self._client:
            return self._transcribe_openai(audio_bytes, filename)
        elif self.provider == "whisper_local":
            return self._transcribe_local(audio_bytes, filename)
        else:
            logger.error("No voice provider configured")
            return None

    def _transcribe_openai(self, audio_bytes: bytes, filename: str) -> Optional[str]:
        """Use OpenAI Whisper API."""
        try:
            audio_file = io.BytesIO(audio_bytes)
            audio_file.name = filename

            response = self._client.audio.transcriptions.create(
                model="whisper-1",
                file=audio_file,
                # language hint is omitted — Whisper auto-detects Greek/German/English
                prompt=(
                    "This is an expense note. The user may say amounts like "
                    "'10 euro coffee', 'βενζίνη 50', 'lidl 30', '15 euro Zigaretten'."
                ),
            )
            text = response.text.strip()
            logger.info(f"Whisper transcription: {text!r}")
            return text
        except Exception as e:
            logger.error(f"OpenAI Whisper error: {e}")
            return None

    def _transcribe_local(self, audio_bytes: bytes, filename: str) -> Optional[str]:
        """Use local whisper model (requires `pip install openai-whisper`)."""
        try:
            import whisper  # type: ignore

            # Write to temp file because whisper reads from disk
            suffix = os.path.splitext(filename)[1] or ".ogg"
            with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
                f.write(audio_bytes)
                tmp_path = f.name

            try:
                model = self._get_local_model()
                result = model.transcribe(
                    tmp_path,
                    task="transcribe",
                    initial_prompt=(
                        "Expense note. Amounts in euros. "
                        "May be in Greek, German, or English."
                    ),
                )
                text = result["text"].strip()
                logger.info(f"Local Whisper transcription: {text!r}")
                return text
            finally:
                os.unlink(tmp_path)

        except ImportError:
            logger.error(
                "Local Whisper not installed. Run: pip install openai-whisper"
            )
            return None
        except Exception as e:
            logger.error(f"Local Whisper error: {e}")
            return None

    _local_model = None

    def _get_local_model(self):
        if self._local_model is None:
            import whisper  # type: ignore
            # "base" is fast and good enough; "small" or "medium" for better accuracy
            model_size = os.getenv("WHISPER_MODEL_SIZE", "base")
            logger.info(f"Loading local Whisper model: {model_size}")
            VoiceTranscriber._local_model = whisper.load_model(model_size)
        return VoiceTranscriber._local_model
