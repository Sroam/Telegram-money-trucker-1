"""
Expense Parser — uses Claude (Haiku) for robust multilingual understanding.

Handles: English, Greek, German, Greeklish, mixed, shorthand, voice input.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Optional

import anthropic

logger = logging.getLogger(__name__)


# ── Parsing result ────────────────────────────────────────────────────────────

@dataclass
class ParsedExpense:
    amount: float
    currency: str
    category: str
    merchant: Optional[str]
    description: str
    expense_date: date
    confidence: float
    raw_input: str


# ── System prompt for Claude ──────────────────────────────────────────────────

SYSTEM_PROMPT = """You are an expense parsing assistant for a personal finance bot.

Your job: extract structured expense data from natural, messy, multilingual text.

INPUT can be:
- English, Greek, German, Greeklish (Greek in Latin chars), or any mix
- Voice-to-text transcription (may have errors)
- Incomplete phrases like "lidl 30" or "kafe 3"
- Natural speech like "yesterday I spent 18 euros on food"

OUTPUT: Return ONLY a valid JSON object. No explanation, no markdown, no extra text.

JSON schema:
{
  "amount": <number or null>,
  "currency": "EUR",
  "category": <string>,
  "merchant": <string or null>,
  "description": <string>,
  "date_offset": <integer: 0=today, -1=yesterday>,
  "confidence": <float 0.0-1.0>
}

CATEGORIES (use exactly these values):
food, coffee, supermarket, gas, cigarettes, shopping, entertainment, transport, bills, health, home, clothes, other

CATEGORY DETECTION RULES:
- coffee / kafe / kaffee / καφές / espresso / latte / cappuccino / frappé → "coffee"
- food / essen / φαγητό / φαΐ / restaurant / taverna / delivery / pizza / souvlaki / gyros / burger / μεζές → "food"
- supermarket / einkaufen / ψώνια / psonia → "supermarket"
- lidl / aldi / rewe / penny / edeka / netto / σκλαβενίτης / ab / ΑΒ / plus / billa / spar → "supermarket"
- gas / tanken / βενζίνη / venzini / petrol / fuel / πρατήριο → "gas"
- shell / bp / aral / esso / total / jet / q8 / revoil / aegean oil → "gas"
- cigarettes / zigaretten / τσιγάρα / tsigara / marlboro / winston / camel → "cigarettes"
- transport / bus / taxi / metro / ubahn / sbahn / εισιτήριο / uber / bahn / zug / train → "transport"
- bills / rechnung / λογαριασμός / electricity / water / internet / phone / ΔΕΗ / ΟΤΕ → "bills"
- health / apotheke / pharmacy / doctor / arzt / ιατρός / φαρμακείο / φάρμακο → "health"
- home / möbel / σπίτι / ikea / obi / leroy → "home"
- clothes / kleidung / ρούχα / rocha / zara / h&m / primark / hm → "clothes"
- entertainment / kino / cinema / σινεμά / bar / club / netflix / spotify / konzert → "entertainment"
- shopping / αγορές / agores (if not more specific) → "shopping"

MERCHANT DETECTION (extract if mentioned):
Known merchants: lidl, aldi, rewe, penny, edeka, netto, spar, billa, σκλαβενίτης, ab, 
  shell, bp, aral, esso, total, revoil, aegean,
  starbucks, costa, nero,
  zara, h&m, primark, ikea, obi, leroy merlin,
  mcdonald's, burger king, subway, dominos, uber eats, wolt

AMOUNT DETECTION:
- Numbers: 12, 12.50, 12,50 → use decimal point
- Word numbers: ten/zehn/δέκα → 10, twenty/zwanzig/είκοσι → 20, thirty/dreißig/τριάντα → 30
- fifty/fünfzig/πενήντα → 50, hundred/hundert/εκατό → 100
- Symbols: €10, 10€, 10 euro, 10 eur, 10 euros → 10

DATE:
- today / heute / σήμερα / simera → 0
- yesterday / gestern / χτες / xthes / χτεσ / xtes → -1
- default → 0

CONFIDENCE:
- Clear amount + clear category → 0.9-1.0
- Clear amount, uncertain category → 0.6-0.8
- No amount found → 0.0-0.3

If amount is missing or you cannot extract a valid expense, set amount to null.

EXAMPLES:
"lidl 30" → {"amount":30,"currency":"EUR","category":"supermarket","merchant":"Lidl","description":"Lidl supermarket","date_offset":0,"confidence":0.95}
"kafe 3" → {"amount":3,"currency":"EUR","category":"coffee","merchant":null,"description":"coffee","date_offset":0,"confidence":0.9}
"βενζίνη 50" → {"amount":50,"currency":"EUR","category":"gas","merchant":null,"description":"fuel","date_offset":0,"confidence":0.95}
"gestern 35 rewe" → {"amount":35,"currency":"EUR","category":"supermarket","merchant":"Rewe","description":"Rewe supermarket","date_offset":-1,"confidence":0.95}
"10 ευρώ καφέ" → {"amount":10,"currency":"EUR","category":"coffee","merchant":null,"description":"coffee","date_offset":0,"confidence":0.95}
"50 euro tanken" → {"amount":50,"currency":"EUR","category":"gas","merchant":null,"description":"fuel","date_offset":0,"confidence":0.95}
"shell 60" → {"amount":60,"currency":"EUR","category":"gas","merchant":"Shell","description":"Shell fuel","date_offset":0,"confidence":0.95}
"yesterday I spent 18 euros on food" → {"amount":18,"currency":"EUR","category":"food","merchant":null,"description":"food","date_offset":-1,"confidence":0.95}
"psonia 25" → {"amount":25,"currency":"EUR","category":"supermarket","merchant":null,"description":"shopping","date_offset":0,"confidence":0.85}
"venzin 40" → {"amount":40,"currency":"EUR","category":"gas","merchant":null,"description":"fuel","date_offset":0,"confidence":0.9}
"""


class ExpenseParser:
    def __init__(self, api_key: str, model: str = "claude-haiku-4-5-20251001") -> None:
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model

    def parse(self, text: str, today: Optional[date] = None) -> Optional[ParsedExpense]:
        """
        Parse natural language expense text. Returns ParsedExpense or None if
        no valid expense could be extracted.
        """
        if today is None:
            today = date.today()

        text = text.strip()
        if not text:
            return None

        # Fast-path: try regex for ultra-simple cases like "30" alone
        # (still goes to Claude but we log it)
        logger.info(f"Parsing input: {text!r}")

        try:
            result = self._call_claude(text)
        except Exception as e:
            logger.error(f"Claude parsing error: {e}")
            # Fallback: try basic regex extraction
            result = self._fallback_parse(text)

        if result is None or result.get("amount") is None:
            return None

        amount = float(result["amount"])
        if amount <= 0:
            return None

        offset = int(result.get("date_offset", 0))
        expense_date = today + timedelta(days=offset)

        merchant_raw = result.get("merchant")
        merchant = self._capitalize_merchant(merchant_raw) if merchant_raw else None

        return ParsedExpense(
            amount=round(amount, 2),
            currency=result.get("currency", "EUR"),
            category=result.get("category", "other"),
            merchant=merchant,
            description=result.get("description", text),
            expense_date=expense_date,
            confidence=float(result.get("confidence", 0.5)),
            raw_input=text,
        )

    def _call_claude(self, text: str) -> Optional[dict]:
        message = self.client.messages.create(
            model=self.model,
            max_tokens=300,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": text}],
        )
        raw = message.content[0].text.strip()
        logger.debug(f"Claude raw response: {raw}")
        return self._safe_json(raw)

    @staticmethod
    def _safe_json(text: str) -> Optional[dict]:
        """Safely parse JSON, tolerating minor formatting issues."""
        text = text.strip()
        # Strip markdown fences if present
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # Try to extract JSON object with regex
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except json.JSONDecodeError:
                    pass
        logger.warning(f"Could not parse JSON from: {text!r}")
        return None

    # ── Fallback regex parser ─────────────────────────────────────────────────

    def _fallback_parse(self, text: str) -> Optional[dict]:
        """
        Basic regex fallback when Claude is unavailable.
        Handles the most common patterns only.
        """
        logger.warning("Using fallback regex parser")
        text_lower = text.lower()

        # Extract amount
        amount = self._extract_amount_regex(text_lower)
        if amount is None:
            return None

        # Date offset
        date_offset = 0
        if any(w in text_lower for w in ["yesterday", "gestern", "χτες", "xthes", "xtes"]):
            date_offset = -1

        # Category from keywords
        category = self._detect_category_regex(text_lower)

        return {
            "amount": amount,
            "currency": "EUR",
            "category": category,
            "merchant": None,
            "description": text[:100],
            "date_offset": date_offset,
            "confidence": 0.4,
        }

    @staticmethod
    def _extract_amount_regex(text: str) -> Optional[float]:
        # Match patterns like: €12, 12€, 12.50, 12,50, 12 euro
        patterns = [
            r"€\s*(\d+(?:[.,]\d{1,2})?)",
            r"(\d+(?:[.,]\d{1,2})?)\s*€",
            r"(\d+(?:[.,]\d{1,2})?)\s*(?:euro|eur|euros)",
            r"(\d+(?:[.,]\d{1,2})?)",
        ]
        for pattern in patterns:
            m = re.search(pattern, text)
            if m:
                val = m.group(1).replace(",", ".")
                try:
                    return float(val)
                except ValueError:
                    continue
        return None

    @staticmethod
    def _detect_category_regex(text: str) -> str:
        rules = [
            ("coffee",      ["coffee", "kaffee", "kafe", "καφ", "espresso", "latte", "cappuccino", "frappe"]),
            ("gas",         ["gas", "fuel", "benzin", "βενζ", "venzin", "petrol", "tanken", "shell", "bp", "aral", "esso"]),
            ("supermarket", ["supermarket", "grocery", "lidl", "aldi", "rewe", "penny", "edeka", "netto", "σκλαβ", "psonia", "ψών"]),
            ("food",        ["food", "essen", "restaurant", "pizza", "burger", "φαγητ", "delivery", "wolt", "souvlaki"]),
            ("cigarettes",  ["cigarette", "zigaretten", "tsigara", "τσιγαρ", "marlboro", "winston"]),
            ("transport",   ["bus", "taxi", "metro", "ubahn", "sbahn", "transport", "bahn", "uber"]),
            ("health",      ["pharmacy", "apotheke", "doctor", "arzt", "φαρμ"]),
            ("bills",       ["bill", "rechnung", "λογαρ", "electricity", "internet", "phone"]),
            ("shopping",    ["shopping", "αγορ", "agores"]),
        ]
        for category, keywords in rules:
            if any(kw in text for kw in keywords):
                return category
        return "other"

    @staticmethod
    def _capitalize_merchant(name: str) -> str:
        """Normalize merchant name capitalization."""
        special = {
            "lidl": "Lidl", "aldi": "Aldi", "rewe": "Rewe", "penny": "Penny",
            "edeka": "Edeka", "netto": "Netto", "spar": "Spar", "billa": "Billa",
            "shell": "Shell", "bp": "BP", "aral": "Aral", "esso": "Esso",
            "total": "Total", "revoil": "Revoil",
            "starbucks": "Starbucks", "costa": "Costa",
            "zara": "Zara", "h&m": "H&M", "ikea": "IKEA", "obi": "OBI",
            "mcdonald's": "McDonald's", "mcdonalds": "McDonald's",
            "ab": "AB", "σκλαβενίτης": "Σκλαβενίτης",
        }
        return special.get(name.lower(), name.title())
