"""
Report generation — produces formatted summaries for Telegram messages.
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import List

from db.database import Database
from db.models import Expense, CATEGORY_EMOJI, CATEGORY_LABELS


class ReportGenerator:
    def __init__(self, db: Database) -> None:
        self.db = db

    # ── Date helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def today() -> date:
        return date.today()

    @staticmethod
    def week_range() -> tuple[date, date]:
        today = date.today()
        start = today - timedelta(days=today.weekday())  # Monday
        return start, today

    @staticmethod
    def month_range() -> tuple[date, date]:
        today = date.today()
        start = today.replace(day=1)
        return start, today

    # ── Report builders ───────────────────────────────────────────────────────

    def daily_summary(self, user_id: int, target_date: date) -> str:
        expenses = self.db.get_expenses_for_date(user_id, target_date)
        label = "Today" if target_date == self.today() else target_date.strftime("%d %b %Y")
        return self._expense_list(expenses, title=f"📅 {label}")

    def weekly_summary(self, user_id: int) -> str:
        start, end = self.week_range()
        expenses = self.db.get_expenses_in_range(user_id, start, end)
        total = sum(e.amount for e in expenses)
        label = f"This Week ({start.strftime('%d %b')} – {end.strftime('%d %b')})"
        return self._expense_list(expenses, title=f"📆 {label}", show_total=True)

    def monthly_summary(self, user_id: int) -> str:
        start, end = self.month_range()
        expenses = self.db.get_expenses_in_range(user_id, start, end)
        label = f"This Month ({start.strftime('%B %Y')})"
        return self._expense_list(expenses, title=f"🗓 {label}", show_total=True)

    def category_report(self, user_id: int, start: date, end: date, title: str) -> str:
        totals = self.db.sum_by_category(user_id, start, end)
        grand_total = self.db.total_in_range(user_id, start, end)

        if not totals:
            return f"📊 {title}\n\nNo expenses recorded."

        lines = [f"📊 *{title}*\n"]
        for category, amount in totals.items():
            emoji = CATEGORY_EMOJI.get(category, "💰")
            label = CATEGORY_LABELS.get(category, category.title())
            pct = (amount / grand_total * 100) if grand_total > 0 else 0
            bar = self._progress_bar(pct)
            lines.append(f"{emoji} *{label}*\n   €{amount:.2f}  {bar}  {pct:.0f}%")

        lines.append(f"\n💶 *Total: €{grand_total:.2f}*")
        return "\n".join(lines)

    def full_report(self, user_id: int, start: date, end: date, title: str) -> str:
        totals = self.db.sum_by_category(user_id, start, end)
        grand_total = self.db.total_in_range(user_id, start, end)
        expenses = self.db.get_expenses_in_range(user_id, start, end)

        if not expenses:
            return f"📋 {title}\n\nNo expenses recorded."

        avg_daily_days = max((end - start).days + 1, 1)
        avg_daily = grand_total / avg_daily_days

        lines = [
            f"📋 *{title}*",
            f"Period: {start.strftime('%d %b')} – {end.strftime('%d %b %Y')}",
            f"",
            f"💶 *Total: €{grand_total:.2f}*",
            f"📊 Daily avg: €{avg_daily:.2f}",
            f"📝 Transactions: {len(expenses)}",
            f"",
            f"*By category:*",
        ]
        for category, amount in totals.items():
            emoji = CATEGORY_EMOJI.get(category, "💰")
            label = CATEGORY_LABELS.get(category, category.title())
            lines.append(f"  {emoji} {label}: €{amount:.2f}")

        # Top 5 expenses
        top5 = sorted(expenses, key=lambda e: e.amount, reverse=True)[:5]
        lines.append(f"\n*Top expenses:*")
        for i, e in enumerate(top5, 1):
            lines.append(
                f"  {i}. {e.category_emoji} €{e.amount:.2f} — "
                f"{e.description[:30]}{e.display_merchant} ({e.date.strftime('%d %b')})"
            )

        return "\n".join(lines)

    def top_expenses(self, user_id: int, n: int = 10) -> str:
        expenses = self.db.get_last_n(user_id, 50)
        top = sorted(expenses, key=lambda e: e.amount, reverse=True)[:n]
        return self._expense_list(top, title=f"🏆 Top {len(top)} Expenses")

    # ── Formatting helpers ────────────────────────────────────────────────────

    @staticmethod
    def _expense_list(
        expenses: List[Expense],
        title: str,
        show_total: bool = False,
    ) -> str:
        if not expenses:
            return f"{title}\n\nNo expenses recorded. Send me a message to add one!"

        lines = [f"*{title}*\n"]
        total = 0.0
        current_date = None

        for e in expenses:
            if show_total and e.date != current_date:
                current_date = e.date
                lines.append(f"\n📅 _{e.date.strftime('%A, %d %b')}_")

            merchant_str = f" @ {e.merchant}" if e.merchant else ""
            lines.append(
                f"{e.category_emoji} €{e.amount:.2f}  {e.description}{merchant_str}"
                + (f"  _(#{e.id})_" if e.id else "")
            )
            total += e.amount

        if show_total:
            lines.append(f"\n💶 *Total: €{total:.2f}*")

        return "\n".join(lines)

    @staticmethod
    def _progress_bar(pct: float, width: int = 8) -> str:
        filled = round(pct / 100 * width)
        return "█" * filled + "░" * (width - filled)
