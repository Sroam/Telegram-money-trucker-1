"""
Export utilities — CSV and Excel (xlsx) generation.
"""
from __future__ import annotations

import csv
import io
import logging
from datetime import date, datetime
from typing import List, Optional

from db.models import Expense, CATEGORY_LABELS

logger = logging.getLogger(__name__)


def expenses_to_csv(expenses: List[Expense]) -> bytes:
    """Export expense list to CSV bytes."""
    output = io.StringIO()
    writer = csv.writer(output, quoting=csv.QUOTE_ALL)

    # Header
    writer.writerow([
        "ID", "Date", "Amount", "Currency", "Category",
        "Merchant", "Description", "Raw Input", "Created At"
    ])

    for e in expenses:
        writer.writerow([
            e.id,
            e.date.isoformat(),
            f"{e.amount:.2f}",
            e.currency,
            CATEGORY_LABELS.get(e.category, e.category),
            e.merchant or "",
            e.description,
            e.raw_input,
            e.created_at.strftime("%Y-%m-%d %H:%M:%S"),
        ])

    return output.getvalue().encode("utf-8-sig")  # UTF-8 BOM for Excel compatibility


def expenses_to_excel(expenses: List[Expense]) -> Optional[bytes]:
    """Export expense list to Excel (.xlsx) bytes. Returns None if openpyxl not installed."""
    try:
        import openpyxl  # type: ignore
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        logger.warning("openpyxl not installed — Excel export unavailable")
        return None

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Expenses"

    # ── Styles ───────────────────────────────────────────────────────────────
    NAVY = "1A2855"
    ORANGE = "E8610A"
    LIGHT_GRAY = "F5F5F5"

    header_font = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill("solid", fgColor=NAVY)
    header_align = Alignment(horizontal="center", vertical="center")

    total_font = Font(name="Calibri", bold=True, color=NAVY, size=11)
    total_fill = PatternFill("solid", fgColor="E8E8E8")

    thin = Side(border_style="thin", color="CCCCCC")
    cell_border = Border(left=thin, right=thin, top=thin, bottom=thin)

    # ── Headers ──────────────────────────────────────────────────────────────
    headers = [
        ("Date", 12),
        ("Amount (€)", 12),
        ("Category", 16),
        ("Merchant", 16),
        ("Description", 30),
        ("Raw Input", 30),
        ("ID", 6),
    ]

    for col_idx, (header, width) in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = cell_border
        ws.column_dimensions[get_column_letter(col_idx)].width = width

    ws.row_dimensions[1].height = 22

    # ── Data rows ─────────────────────────────────────────────────────────────
    totals_by_category: dict[str, float] = {}

    for row_idx, e in enumerate(expenses, 2):
        fill = PatternFill("solid", fgColor=LIGHT_GRAY) if row_idx % 2 == 0 else None
        category_label = CATEGORY_LABELS.get(e.category, e.category.title())
        row_data = [
            e.date.strftime("%d/%m/%Y"),
            round(e.amount, 2),
            category_label,
            e.merchant or "",
            e.description,
            e.raw_input,
            e.id,
        ]
        for col_idx, value in enumerate(row_data, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.border = cell_border
            cell.alignment = Alignment(vertical="center")
            if fill:
                cell.fill = fill
            # Format amount column
            if col_idx == 2:
                cell.number_format = '#,##0.00 "€"'
                cell.alignment = Alignment(horizontal="right", vertical="center")

        totals_by_category[e.category] = totals_by_category.get(e.category, 0) + e.amount

    # ── Summary sheet ─────────────────────────────────────────────────────────
    ws2 = wb.create_sheet("Summary")
    ws2.column_dimensions["A"].width = 20
    ws2.column_dimensions["B"].width = 15

    ws2.cell(1, 1, "Category").font = Font(bold=True, color="FFFFFF")
    ws2.cell(1, 1).fill = PatternFill("solid", fgColor=NAVY)
    ws2.cell(1, 2, "Total (€)").font = Font(bold=True, color="FFFFFF")
    ws2.cell(1, 2).fill = PatternFill("solid", fgColor=NAVY)

    grand_total = 0.0
    for row_i, (cat, total) in enumerate(
        sorted(totals_by_category.items(), key=lambda x: x[1], reverse=True), 2
    ):
        label = CATEGORY_LABELS.get(cat, cat.title())
        ws2.cell(row_i, 1, label)
        cell_total = ws2.cell(row_i, 2, round(total, 2))
        cell_total.number_format = '#,##0.00 "€"'
        cell_total.alignment = Alignment(horizontal="right")
        grand_total += total

    # Grand total row
    total_row = len(totals_by_category) + 2
    gt_label = ws2.cell(total_row, 1, "TOTAL")
    gt_label.font = total_font
    gt_label.fill = total_fill

    gt_val = ws2.cell(total_row, 2, round(grand_total, 2))
    gt_val.font = total_font
    gt_val.fill = total_fill
    gt_val.number_format = '#,##0.00 "€"'
    gt_val.alignment = Alignment(horizontal="right")

    # ── Freeze panes & auto-filter ────────────────────────────────────────────
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:G{len(expenses) + 1}"

    output = io.BytesIO()
    wb.save(output)
    return output.getvalue()
