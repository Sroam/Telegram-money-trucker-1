"""
Message formatting helpers for Telegram (MarkdownV2-safe).
"""
from __future__ import annotations

from datetime import date

from db.models import Expense, CATEGORY_LABELS


def fmt_expense_added(expense: Expense) -> str:
    """Confirmation message after successfully adding an expense."""
    date_label = "Today" if expense.expense_date == date.today() else expense.expense_date.strftime("%d %b %Y")
    merchant_str = f"\n🏪 *Merchant:* {expense.merchant}" if expense.merchant else ""
    cat_label = CATEGORY_LABELS.get(expense.category, expense.category.title())

    return (
        f"✅ *Expense added!*\n\n"
        f"💶 *Amount:* €{expense.amount:.2f}\n"
        f"{expense.category_emoji} *Category:* {cat_label}\n"
        f"{merchant_str}"
        f"📅 *Date:* {date_label}\n"
        f"📝 *Note:* {expense.description}\n\n"
        f"_Send another expense or use /today to see today's list._"
    ).replace("merchant_str\n", "")


def fmt_expense_added_from_model(expense: Expense) -> str:
    """Better version that handles merchant_str cleanly."""
    date_label = "Today" if expense.expense_date == date.today() else expense.expense_date.strftime("%d %b %Y")
    cat_label = CATEGORY_LABELS.get(expense.category, expense.category.title())

    lines = [
        "✅ *Expense added!*\n",
        f"💶 *Amount:* €{expense.amount:.2f}",
        f"{expense.category_emoji} *Category:* {cat_label}",
    ]
    if expense.merchant:
        lines.append(f"🏪 *Merchant:* {expense.merchant}")
    lines.append(f"📅 *Date:* {date_label}")
    lines.append(f"📝 *Note:* {expense.description}")
    lines.append("\n_Send another expense or use /today for today's list._")

    return "\n".join(lines)


def fmt_deleted(expense: Expense) -> str:
    return (
        f"🗑 *Deleted:*\n"
        f"€{expense.amount:.2f} — {expense.description}"
        + (f" @ {expense.merchant}" if expense.merchant else "")
        + f"\n\n_Use /undo again if you need to remove another one._"
    )


def fmt_no_expenses() -> str:
    return (
        "📭 No expenses found for this period.\n\n"
        "Send me a message like:\n"
        "  • _10 euro coffee_\n"
        "  • _βενζίνη 50_\n"
        "  • _lidl 35_\n"
        "  • Or a 🎤 voice note!"
    )


def fmt_parse_failed(raw_input: str) -> str:
    return (
        f"🤔 I couldn't understand: _{raw_input}_\n\n"
        f"Try formats like:\n"
        f"  • _10 euro coffee_\n"
        f"  • _βενζίνη 50_\n"
        f"  • _lidl 35_\n"
        f"  • _50 euro tanken_\n\n"
        f"Or just send a 🎤 voice note describing the expense."
    )


def fmt_not_authorized() -> str:
    return "⛔ You are not authorized to use this bot."


HELP_TEXT = """
🤖 *Expense Tracker Bot*

*Add an expense* — just send a message or voice note:
  • `10 euro coffee`
  • `βενζίνη 50`
  • `lidl 30`
  • `gestern 15 euro essen`
  • Or any voice note! 🎤

*View expenses:*
  /today — Today's expenses
  /week — This week
  /month — This month
  /expenses — Last 10 entries
  /last — Show last 5 entries

*Reports:*
  /report — Full monthly report
  /categories — Spending by category
  /top — Top 10 biggest expenses

*Edit / Undo:*
  /delete\\_last — Delete last expense
  /undo — Same as above

*Export:*
  /export — Download as CSV
  /export\\_excel — Download as Excel

*Languages supported:*
🇬🇧 English  🇬🇷 Greek  🇩🇪 German  Greeklish ✓
""".strip()


START_TEXT = """
👋 *Welcome to Expense Tracker!*

I'll help you track your daily expenses.

Just send me a message or 🎤 voice note:
  • `10 euro coffee`
  • `βενζίνη 50`
  • `lidl 30`
  • `gestern tanken 45`

Use /help to see all commands.
""".strip()
