# 💸 Expense Tracker Telegram Bot

A personal finance bot that understands **voice and text** in **English, Greek, German, and Greeklish**. Powered by Claude (Anthropic) for intelligent multilingual parsing and OpenAI Whisper for voice transcription.

---

## Features

- 🎤 **Voice notes** → automatically transcribed and parsed
- 🌍 **Multilingual**: English, Greek (ελληνικά), German (Deutsch), Greeklish
- 🧠 **AI parsing**: understands messy, incomplete, natural input
- 📊 **Reports**: daily, weekly, monthly, by category
- 📁 **Export**: CSV and Excel (.xlsx)
- 🗑 **Undo**: delete last expense instantly
- 🔒 **User whitelist**: personal use only

---

## Example Inputs (all understood correctly)

```
10 euro coffee
βενζίνη 50
lidl 30
gestern 35 rewe
kafe 3
shell 60
ψώνια 25
50 euro tanken
χτες 18 ευρώ φαγητό
zigaretten 15
venzin 40
psonia 25 euro
yesterday I spent 20 on food
heute 8 kaffee
```

---

## Setup Instructions

### Step 1 — Clone and install dependencies

```bash
# Create a folder for the bot
mkdir expense-bot && cd expense-bot

# Copy all bot files here (or clone from repo)

# Create a virtual environment
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Step 2 — Create a Telegram bot

1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. Follow the prompts and copy your **bot token**

### Step 3 — Get your Telegram user ID

1. Open Telegram and search for **@userinfobot**
2. Send any message — it will reply with your user ID
3. Copy the number (e.g., `123456789`)

### Step 4 — Configure environment

```bash
cp .env.example .env
```

Edit `.env` and fill in:

```env
TELEGRAM_BOT_TOKEN=your_bot_token
ANTHROPIC_API_KEY=your_anthropic_key
OPENAI_API_KEY=your_openai_key
ALLOWED_USER_IDS=123456789
```

**API Keys:**
- **Anthropic**: https://console.anthropic.com/ (used for parsing)
- **OpenAI**: https://platform.openai.com/api-keys (used for Whisper voice)

> **No OpenAI account?** Set `VOICE_PROVIDER=whisper_local` and run:
> ```bash
> pip install openai-whisper
> # Also install ffmpeg: https://ffmpeg.org/download.html
> ```

### Step 5 — Run the bot

```bash
python bot.py
```

You should see:
```
Database initialized at: expenses.db
Bot is running — waiting for messages…
```

### Step 6 — Test it

Open your bot in Telegram and send:
```
/start
10 euro coffee
```

---

## Commands Reference

| Command | Description |
|---------|-------------|
| `/today` | Today's expenses |
| `/week` | This week's expenses |
| `/month` | This month's expenses |
| `/expenses` | Last 10 entries |
| `/last` | Last 5 entries |
| `/report` | Full monthly report |
| `/categories` | Spending by category (with bar chart) |
| `/top` | Top 10 biggest expenses |
| `/delete_last` | Delete the last expense |
| `/undo` | Same as `/delete_last` |
| `/export` | Download expenses as CSV |
| `/export_excel` | Download expenses as Excel |
| `/help` | Show help message |

---

## Categories

| Category | Keywords detected |
|----------|------------------|
| ☕ Coffee | coffee, kaffee, kafe, καφές, espresso, latte, frappé |
| 🍔 Food | food, essen, φαγητό, restaurant, pizza, souvlaki, delivery |
| 🛒 Supermarket | supermarket, lidl, aldi, rewe, penny, edeka, ψώνια |
| ⛽ Gas | gas, tanken, βενζίνη, shell, bp, aral, esso |
| 🚬 Cigarettes | cigarettes, zigaretten, τσιγάρα, marlboro |
| 🚌 Transport | bus, taxi, metro, ubahn, uber, εισιτήριο |
| 💊 Health | pharmacy, apotheke, φαρμακείο, doctor |
| 📄 Bills | bill, rechnung, ΔΕΗ, ΟΤΕ, internet |
| 🏠 Home | home, ikea, obi, σπίτι |
| 👕 Clothes | clothes, zara, h&m, primark, ρούχα |
| 🎬 Entertainment | cinema, bar, netflix, spotify, σινεμά |
| 🛍️ Shopping | shopping, αγορές (generic) |
| 💰 Other | anything else |

---

## Architecture

```
expense-bot/
├── bot.py                    # Entry point
├── config.py                 # Environment config
├── requirements.txt
├── .env                      # Your secrets (not committed)
├── handlers/
│   ├── commands.py           # /today, /week, /month, etc.
│   └── messages.py           # Text + voice message processing
├── core/
│   ├── parser.py             # Claude-powered multilingual parser
│   ├── voice.py              # Whisper voice-to-text
│   └── reports.py            # Report generation
├── db/
│   ├── database.py           # SQLite operations
│   └── models.py             # Data models
└── utils/
    ├── export.py             # CSV + Excel export
    └── formatters.py         # Telegram message formatting
```

---

## Running in Production (Linux server / VPS)

### With systemd:

```bash
# Create service file
sudo nano /etc/systemd/system/expense-bot.service
```

```ini
[Unit]
Description=Expense Tracker Telegram Bot
After=network.target

[Service]
Type=simple
User=your_user
WorkingDirectory=/path/to/expense-bot
ExecStart=/path/to/expense-bot/venv/bin/python bot.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable expense-bot
sudo systemctl start expense-bot
sudo systemctl status expense-bot
```

### View logs:
```bash
journalctl -u expense-bot -f
```

---

## Cost Estimate

| Service | Usage | Est. Cost/month |
|---------|-------|-----------------|
| Claude Haiku (parsing) | ~30 expenses/day | ~$0.10 |
| OpenAI Whisper (voice) | ~10 voice notes/day | ~$0.15 |
| **Total** | | **~$0.25/month** |

Very affordable for personal use.

---

## Upgrade Path

- [ ] PostgreSQL instead of SQLite (multi-user)
- [ ] Google Sheets sync
- [ ] Monthly budget alerts
- [ ] Recurring expense detection
- [ ] Telegram inline keyboard for category correction
- [ ] Web dashboard (FastAPI + Chart.js)
