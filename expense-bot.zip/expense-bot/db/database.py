"""
Database layer — SQLite via standard library sqlite3
"""
from __future__ import annotations

import sqlite3
import logging
from datetime import date, datetime
from typing import List, Optional, Dict

from db.models import Expense

logger = logging.getLogger(__name__)


class Database:
    def __init__(self, path: str) -> None:
        self.path = path

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    # ── Schema ───────────────────────────────────────────────────────────────

    def initialize(self) -> None:
        with self._connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS users (
                    telegram_id  INTEGER PRIMARY KEY,
                    username     TEXT,
                    first_name   TEXT,
                    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS expenses (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id      INTEGER NOT NULL,
                    amount       REAL    NOT NULL,
                    currency     TEXT    NOT NULL DEFAULT 'EUR',
                    category     TEXT    NOT NULL DEFAULT 'other',
                    merchant     TEXT,
                    description  TEXT    NOT NULL DEFAULT '',
                    raw_input    TEXT    NOT NULL DEFAULT '',
                    date         DATE    NOT NULL,
                    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(telegram_id)
                );

                CREATE INDEX IF NOT EXISTS idx_expenses_user_date
                    ON expenses (user_id, date);

                CREATE INDEX IF NOT EXISTS idx_expenses_category
                    ON expenses (user_id, category);
            """)
        logger.info("Database schema ready")

    # ── User management ──────────────────────────────────────────────────────

    def upsert_user(self, telegram_id: int, username: str, first_name: str) -> None:
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO users (telegram_id, username, first_name)
                VALUES (?, ?, ?)
                ON CONFLICT(telegram_id) DO UPDATE SET
                    username   = excluded.username,
                    first_name = excluded.first_name
            """, (telegram_id, username, first_name))

    # ── Expense CRUD ─────────────────────────────────────────────────────────

    def add_expense(self, expense: Expense) -> int:
        with self._connect() as conn:
            cur = conn.execute("""
                INSERT INTO expenses
                    (user_id, amount, currency, category, merchant,
                     description, raw_input, date)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                expense.user_id,
                expense.amount,
                expense.currency,
                expense.category,
                expense.merchant,
                expense.description,
                expense.raw_input,
                expense.date.isoformat(),
            ))
            return cur.lastrowid  # type: ignore

    def delete_last(self, user_id: int) -> Optional[Expense]:
        """Delete and return the most recent expense for a user."""
        with self._connect() as conn:
            row = conn.execute("""
                SELECT * FROM expenses
                WHERE user_id = ?
                ORDER BY created_at DESC
                LIMIT 1
            """, (user_id,)).fetchone()

            if not row:
                return None

            expense = self._row_to_expense(row)
            conn.execute("DELETE FROM expenses WHERE id = ?", (row["id"],))
            return expense

    def delete_by_id(self, user_id: int, expense_id: int) -> bool:
        with self._connect() as conn:
            cur = conn.execute(
                "DELETE FROM expenses WHERE id = ? AND user_id = ?",
                (expense_id, user_id)
            )
            return cur.rowcount > 0

    # ── Queries ──────────────────────────────────────────────────────────────

    def get_expenses_for_date(self, user_id: int, target_date: date) -> List[Expense]:
        with self._connect() as conn:
            rows = conn.execute("""
                SELECT * FROM expenses
                WHERE user_id = ? AND date = ?
                ORDER BY created_at DESC
            """, (user_id, target_date.isoformat())).fetchall()
        return [self._row_to_expense(r) for r in rows]

    def get_expenses_in_range(
        self, user_id: int, start: date, end: date
    ) -> List[Expense]:
        with self._connect() as conn:
            rows = conn.execute("""
                SELECT * FROM expenses
                WHERE user_id = ? AND date BETWEEN ? AND ?
                ORDER BY date DESC, created_at DESC
            """, (user_id, start.isoformat(), end.isoformat())).fetchall()
        return [self._row_to_expense(r) for r in rows]

    def get_last_n(self, user_id: int, n: int = 10) -> List[Expense]:
        with self._connect() as conn:
            rows = conn.execute("""
                SELECT * FROM expenses
                WHERE user_id = ?
                ORDER BY created_at DESC
                LIMIT ?
            """, (user_id, n)).fetchall()
        return [self._row_to_expense(r) for r in rows]

    def get_all(self, user_id: int) -> List[Expense]:
        with self._connect() as conn:
            rows = conn.execute("""
                SELECT * FROM expenses
                WHERE user_id = ?
                ORDER BY date DESC, created_at DESC
            """, (user_id,)).fetchall()
        return [self._row_to_expense(r) for r in rows]

    # ── Aggregates ───────────────────────────────────────────────────────────

    def sum_by_category(
        self, user_id: int, start: date, end: date
    ) -> Dict[str, float]:
        with self._connect() as conn:
            rows = conn.execute("""
                SELECT category, SUM(amount) as total
                FROM expenses
                WHERE user_id = ? AND date BETWEEN ? AND ?
                GROUP BY category
                ORDER BY total DESC
            """, (user_id, start.isoformat(), end.isoformat())).fetchall()
        return {r["category"]: round(r["total"], 2) for r in rows}

    def total_in_range(self, user_id: int, start: date, end: date) -> float:
        with self._connect() as conn:
            row = conn.execute("""
                SELECT COALESCE(SUM(amount), 0) as total
                FROM expenses
                WHERE user_id = ? AND date BETWEEN ? AND ?
            """, (user_id, start.isoformat(), end.isoformat())).fetchone()
        return round(row["total"], 2)

    # ── Helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def _row_to_expense(row: sqlite3.Row) -> Expense:
        return Expense(
            id=row["id"],
            user_id=row["user_id"],
            amount=row["amount"],
            currency=row["currency"],
            category=row["category"],
            merchant=row["merchant"],
            description=row["description"],
            raw_input=row["raw_input"],
            date=date.fromisoformat(row["date"]),
            created_at=datetime.fromisoformat(row["created_at"]),
        )
