"""
Data models — plain dataclasses, no ORM dependency
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Optional


@dataclass
class Expense:
    id: Optional[int]
    user_id: int
    amount: float
    currency: str
    category: str
    merchant: Optional[str]
    description: str
    raw_input: str
    date: date
    created_at: datetime

    @property
    def amount_str(self) -> str:
        symbol = "€" if self.currency == "EUR" else self.currency
        return f"{symbol}{self.amount:.2f}"

    @property
    def category_emoji(self) -> str:
        return CATEGORY_EMOJI.get(self.category, "💰")

    @property
    def display_merchant(self) -> str:
        return f" @ {self.merchant}" if self.merchant else ""


CATEGORY_EMOJI: dict[str, str] = {
    "food": "🍔",
    "coffee": "☕",
    "supermarket": "🛒",
    "gas": "⛽",
    "cigarettes": "🚬",
    "shopping": "🛍️",
    "entertainment": "🎬",
    "transport": "🚌",
    "bills": "📄",
    "health": "💊",
    "home": "🏠",
    "clothes": "👕",
    "other": "💰",
}

CATEGORY_LABELS: dict[str, str] = {
    "food": "Food",
    "coffee": "Coffee",
    "supermarket": "Supermarket",
    "gas": "Gas / Fuel",
    "cigarettes": "Cigarettes",
    "shopping": "Shopping",
    "entertainment": "Entertainment",
    "transport": "Transport",
    "bills": "Bills",
    "health": "Health",
    "home": "Home",
    "clothes": "Clothes",
    "other": "Other",
}

ALL_CATEGORIES = list(CATEGORY_LABELS.keys())
