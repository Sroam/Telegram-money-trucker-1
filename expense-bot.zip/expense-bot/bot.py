"""
Expense Tracker Telegram Bot — Main Entry Point
"""
import logging
import sys
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
)

from config import Config
from db.database import Database
from handlers.commands import CommandHandlers
from handlers.messages import MessageHandlers

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
    stream=sys.stdout,
)
logger = logging.getLogger(__name__)


def main() -> None:
    config = Config()
    config.validate()

    db = Database(config.DATABASE_PATH)
    db.initialize()
    logger.info(f"Database initialized at: {config.DATABASE_PATH}")

    cmd = CommandHandlers(db=db, config=config)
    msg = MessageHandlers(db=db, config=config)

    app = Application.builder().token(config.TELEGRAM_BOT_TOKEN).build()

    # ── Info commands ────────────────────────────────────────────────────────
    app.add_handler(CommandHandler("start", cmd.start))
    app.add_handler(CommandHandler("help", cmd.help))

    # ── Expense views ────────────────────────────────────────────────────────
    app.add_handler(CommandHandler("today", cmd.today))
    app.add_handler(CommandHandler("week", cmd.week))
    app.add_handler(CommandHandler("month", cmd.month))
    app.add_handler(CommandHandler("expenses", cmd.expenses))

    # ── Reports ──────────────────────────────────────────────────────────────
    app.add_handler(CommandHandler("report", cmd.report))
    app.add_handler(CommandHandler("categories", cmd.categories))
    app.add_handler(CommandHandler("top", cmd.top_expenses))

    # ── Edit / Undo ──────────────────────────────────────────────────────────
    app.add_handler(CommandHandler("delete_last", cmd.delete_last))
    app.add_handler(CommandHandler("undo", cmd.delete_last))
    app.add_handler(CommandHandler("last", cmd.show_last))

    # ── Export ───────────────────────────────────────────────────────────────
    app.add_handler(CommandHandler("export", cmd.export_csv))
    app.add_handler(CommandHandler("export_excel", cmd.export_excel))

    # ── Message handlers (text + voice) ──────────────────────────────────────
    app.add_handler(MessageHandler(filters.VOICE, msg.handle_voice))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, msg.handle_text))

    logger.info("Bot is running — waiting for messages…")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
